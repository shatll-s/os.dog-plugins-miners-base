#!/bin/bash

# parse args
parse_args() {
    # os.dog passes the addition field as multi-line text (one -o pool per line for
    # failover). Flatten newlines/CRs to spaces so `read` below tokenizes ALL args,
    # not just the first line.
    local args="${1//[$'\n\r']/ }"
    shift
    local keys=("$@")

    read -ra tokens <<< "$args"
    local filtered=()

    for ((i = 0; i < ${#tokens[@]}; i++)); do
        local token="${tokens[i]}"
        local is_key=0

        for key in "${keys[@]}"; do
            if [[ "$token" == "--$key" || "$token" == "-${key:0:1}" ]]; then
                local var_name="${key//-/_}"
                if (( i + 1 < ${#tokens[@]} )); then
                    local value="${tokens[$((i+1))]}"
                    export "${var_name}=$value"
                else
                    export "${var_name}="
                fi
                ((i++))
                is_key=1
                break
            elif [[ "$token" == "--$key="* ]]; then
                local var_name="${key//-/_}"
                local value="${token#--$key=}"
                export "${var_name}=$value"
                is_key=1
                break
            fi
        done

        if [[ $is_key -eq 0 ]]; then
            filtered+=("${token}")
        fi
    done

    REMAINING_ARGS="${filtered[*]}"
}

# free port - kill process using the port
free_port() {
    local port="$1"
    if [[ -z "$port" ]]; then
        return 1
    fi
    local pid=$(fuser "$port/tcp" 2>/dev/null)
    if [[ -n "$pid" ]]; then
        echo "> Port $port is busy (PID: $pid), killing..."
        kill -9 $pid 2>/dev/null
        sleep 1
    fi
}
